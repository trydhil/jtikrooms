<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Booking;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class BookingController extends Controller
{
    // CREATE - Form booking dari QR code
    public function createFromQR($roomName)
    {
        // ✅ TEMPORARY: Skip semua validasi QR
        // $referer = request()->header('referer');
        // $isFromQR = $referer && (str_contains($referer, '/qr/scanner') || str_contains($referer, url('/qr/scanner')));
        
        // if (!$isFromQR) {
        //     abort(403, 'Akses booking hanya melalui scan QR code.');
        // }
        
        // Decode URL parameter
        $roomName = urldecode($roomName);
        
        // Validasi ruangan exists
        $validRooms = [
            'AE 101', 'AE 102', 'AE 103', 'AE 104', 'AE 105', 'AE 106', 'AE 107', 'AE 209',
            'Lab Animasi', 'IT Workshop', 'Lab Jaringan', 'Lab Programing', 'Lab Sistem Cerdas', 'Lab Embeded',
            'Sekretariat HIMATIK', 'Ruangan Admin', 'Perpustakaan', 'Ruangan Sekertaris Jurusan',
            'Ruangan Kepala Laboratorium', 'Ruangan Dosen', 'Ruangan Ketua Prodi TEKOM', 
            'Ruangan Ujian', 'Ruangan Ketua Prodi PTIK'
        ];
        
        if (!in_array($roomName, $validRooms)) {
            abort(404, 'Ruangan tidak ditemukan');
        }
        
        return view('booking.create', [
            'roomName' => $roomName
        ]);
    }

   public function store(Request $request)
{
    if (!session('user')) {
        Log::error('❌ NO USER SESSION - Redirect to login');
        return redirect()->route('login')->with('error', 'Silakan login terlebih dahulu.');
    }

    Log::info('🎯 BOOKING ATTEMPT', [
        'user' => session('user'),
        'room' => $request->room_name
    ]);

    // Validasi input form
    $request->validate([
        'room_name' => 'required',
        'mata_kuliah' => 'required',
        'dosen' => 'required',
        'waktu_berakhir' => 'required|date|after:now',
        'keterangan' => 'nullable'
    ]);

    try {
        $waktuMulai = now()->timezone('Asia/Makassar');
        $waktuBerakhir = Carbon::parse($request->waktu_berakhir)->timezone('Asia/Makassar');
        
        $durationMinutes = $waktuMulai->diffInMinutes($waktuBerakhir);
        
        Log::info('⏰ TIME VALIDATION', [
            'start' => $waktuMulai->format('Y-m-d H:i:s'),
            'end' => $waktuBerakhir->format('Y-m-d H:i:s'), 
            'duration_minutes' => $durationMinutes
        ]);

        // Validasi minimal 30 menit
        if ($durationMinutes < 30) {
            Log::warning('❌ DURATION TOO SHORT', ['minutes' => $durationMinutes]);
            return back()->with('error', 'Booking minimal 30 menit dari waktu sekarang.')->withInput();
        }

        // Overlap checking
        $overlap = Booking::where('room_name', $request->room_name)
            ->where('status', 'active')
            ->where(function($query) use ($waktuMulai, $waktuBerakhir) {
                $query->where(function($q) use ($waktuMulai, $waktuBerakhir) {
                    $q->where('waktu_mulai', '<', $waktuBerakhir)
                      ->where('waktu_berakhir', '>', $waktuMulai);
                });
            })
            ->exists();

        if ($overlap) {
            Log::warning('❌ ROOM OVERLAP', ['room' => $request->room_name]);
            return back()
                ->with('error', 'Ruangan sudah dibooking pada waktu tersebut. Silakan pilih waktu lain.')
                ->withInput();
        }

        // Buat booking
        $booking = Booking::create([
            'room_name' => $request->room_name,
            'username' => session('user'),
            'mata_kuliah' => $request->mata_kuliah,
            'dosen' => $request->dosen,
            'waktu_mulai' => $waktuMulai,
            'waktu_berakhir' => $waktuBerakhir,
            'status' => 'active',
            'keterangan' => $request->keterangan
        ]);

        Log::info('✅ BOOKING SUCCESS', [
            'booking_id' => $booking->id,
            'room' => $request->room_name,
            'user' => session('user')
        ]);

        return redirect()
            ->route('dashboard.kelas')
            ->with('success', 'Booking berhasil! Ruangan: ' . $request->room_name);

    } catch (\Exception $e) {
        Log::error('💥 BOOKING FAILED', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
            'user' => session('user'),
            'room' => $request->room_name
        ]);

        return back()
            ->with('error', 'Gagal membuat booking: ' . $e->getMessage()) // Tampilkan error detail
            ->withInput();
    }
}
    // READ - Booking aktif untuk user (di dashboard kelas)
   public function getActiveBookings()
{
    try {
        return Booking::where('username', session('user'))
            ->where('status', 'active')
            ->where('waktu_berakhir', '>', now()->timezone('Asia/Makassar')) // ✅ FIX TIMEZONE
            ->orderBy('waktu_berakhir')
            ->get();
            
    } catch (\Exception $e) {
        Log::error('Failed to get active bookings', [
            'error' => $e->getMessage(),
            'user' => session('user')
        ]);
        
        return collect();
    }
}

    // UPDATE - Batalkan booking
    public function cancel($id)
    {
        try {
            $booking = Booking::findOrFail($id);
            
            if ($booking->username !== session('user')) {
                Log::warning('Unauthorized cancel attempt', [
                    'booking_id' => $id,
                    'booking_owner' => $booking->username,
                    'attempt_by' => session('user')
                ]);
                
                return back()->with('error', 'Anda tidak berhak membatalkan booking ini!');
            }

            if ($booking->waktu_berakhir < now()) {
                return back()->with('error', 'Tidak dapat membatalkan booking yang sudah berakhir!');
            }

            $booking->update(['status' => 'cancelled']);

            Log::info('Booking cancelled', [
                'booking_id' => $id,
                'room' => $booking->room_name,
                'user' => session('user')
            ]);

            return back()->with('success', 'Booking berhasil dibatalkan!');

        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            Log::error('Booking not found for cancellation', [
                'booking_id' => $id,
                'user' => session('user')
            ]);
            
            return back()->with('error', 'Booking tidak ditemukan!');
            
        } catch (\Exception $e) {
            Log::error('Booking cancellation failed', [
                'error' => $e->getMessage(),
                'booking_id' => $id,
                'user' => session('user')
            ]);
            
            return back()->with('error', 'Gagal membatalkan booking. Silakan coba lagi.');
        }
    }

    // READ - Semua booking aktif (untuk admin)
 public function getAllBookings()
{
    try {
        return Booking::where('status', 'active')
            ->where('waktu_berakhir', '>', now()->timezone('Asia/Makassar')) // ✅ FIX TIMEZONE
            ->orderBy('waktu_berakhir')
            ->get();
            
    } catch (\Exception $e) {
        Log::error('Failed to get all bookings', [
            'error' => $e->getMessage(),
            'admin' => session('user')
        ]);
        
        return collect();
    }
}
    // BONUS: Auto-expire booking yang sudah lewat
    public function expireOldBookings()
    {
        try {
            $expired = Booking::where('status', 'active')
                ->where('waktu_berakhir', '<', now())
                ->update(['status' => 'completed']);

            Log::info('Auto-expired bookings', ['count' => $expired]);

            return response()->json([
                'success' => true,
                'expired_count' => $expired
            ]);

        } catch (\Exception $e) {
            Log::error('Auto-expire failed', ['error' => $e->getMessage()]);
            
            return response()->json([
                'success' => false,
                'message' => 'Gagal expire booking'
            ], 500);
        }
    }
}