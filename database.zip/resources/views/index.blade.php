@extends('layouts.app')

@section('title', 'Dasher - Dashboard Ruangan')

@section('content')
<div class="header">
    <h2><i class="fas fa-th-list me-2"></i>Dashboard Ruangan</h2>
    <div class="user-info">
        <div class="user-avatar-small"><i class="fas fa-user"></i></div>
    </div>
</div>

<div class="search-bar">
    <input type="text" class="search-input" placeholder="Cari ruangan..." />
    <button class="search-button"><i class="fas fa-search"></i></button>
</div>

<div class="filter-bar">
    <button class="filter-button active" data-filter="kelas">Ruangan Kelas</button>
    <button class="filter-button" data-filter="lab">Laboratorium</button>
    <button class="filter-button" data-filter="other">Ruangan Lainnya</button>
</div>

<div class="room-list">
    </div>

<div class="card mt-4">
    <div class="card-header bg-white py-3">
        <h3 class="card-title mb-0" style="color: var(--oranye)">
            <i class="fas fa-map-marked-alt me-2"></i>Peta Ruangan
        </h3>
    </div>
    <div class="card-body p-0 position-relative">
        <div class="d-block d-lg-none position-absolute top-0 end-0 m-2 z-1">
            <button class="btn btn-primary btn-sm shadow" onclick="openMapFullscreen()" 
                    style="background: var(--oranye); border: none; border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center;">
                <i class="fas fa-expand"></i>
            </button>
        </div>

        <div class="map-container">
            <div class="floor-controls">
                <div class="btn-group shadow-sm">
                    <button class="btn btn-light active btn-floor" onclick="changeFloor(1, this)">Lantai 1</button>
                    <button class="btn btn-light btn-floor" onclick="changeFloor(2, this)">Lantai 2</button>
                </div>
            </div>
            <img id="floorMap" src="{{ asset('img/lantai1.png') }}" alt="Floor Plan" class="w-100 d-block" />
        </div>
    </div>
</div>

<div id="mapModal" class="modal fade" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" style="background: rgba(0,0,0,0.95);">
    <div class="modal-dialog modal-fullscreen p-0 m-0">
        <div class="modal-content bg-transparent border-0 h-100 w-100 position-relative">
            
            <button type="button" class="btn-close btn-close-white position-absolute top-0 end-0 m-3 z-3 shadow-none" 
                    data-bs-dismiss="modal" aria-label="Close" style="width: 1.5rem; height: 1.5rem;"></button>

            <div class="position-absolute top-0 start-0 m-3 z-3">
                <div class="btn-group shadow-sm" role="group">
                    <button class="btn btn-dark btn-sm border-0" id="zoomOutBtn" style="background: rgba(255,255,255,0.2); backdrop-filter: blur(4px);"><i class="fas fa-minus"></i></button>
                    <button class="btn btn-dark btn-sm border-0" id="resetBtn" style="background: rgba(255,255,255,0.2); backdrop-filter: blur(4px);">Reset</button>
                    <button class="btn btn-dark btn-sm border-0" id="zoomInBtn" style="background: rgba(255,255,255,0.2); backdrop-filter: blur(4px);"><i class="fas fa-plus"></i></button>
                </div>
            </div>

            <div class="modal-body p-0 h-100 w-100 d-flex align-items-center justify-content-center overflow-hidden" id="panzoom-canvas">
                <img id="floorMapModal" src="{{ asset('img/lantai1.png') }}" alt="Floor Plan" />
            </div>

            <div class="position-absolute bottom-0 start-50 translate-middle-x mb-4 z-3">
                <div class="btn-group shadow" style="border-radius: 50px; overflow: hidden; background: rgba(255,255,255,0.15); backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.2);">
                    <button class="btn btn-link text-decoration-none text-white btn-floor-modal active" onclick="changeFloorModal(1, this)">Lantai 1</button>
                    <button class="btn btn-link text-decoration-none text-white btn-floor-modal" onclick="changeFloorModal(2, this)">Lantai 2</button>
                </div>
            </div>

        </div>
    </div>
</div>

<script src="https://unpkg.com/@panzoom/panzoom@4.5.1/dist/panzoom.min.js"></script>

<script>
    let mapPanzoom = null;

    /* --- 1. BUKA MODAL --- */
    function openMapFullscreen() {
        const currentSrc = document.getElementById('floorMap').src;
        const modalImg = document.getElementById('floorMapModal');
        
        modalImg.src = currentSrc;
        
        const isLantai2 = currentSrc.includes('lantai2');
        updateModalButtons(isLantai2 ? 2 : 1);

        const modalEl = document.getElementById('mapModal');
        const modal = new bootstrap.Modal(modalEl);
        modal.show();
    }

    /* --- 2. SETTING ZOOM (PERBAIKAN UTAMA) --- */
    document.getElementById('mapModal').addEventListener('shown.bs.modal', function () {
        const element = document.getElementById('floorMapModal');
        
        if (mapPanzoom) mapPanzoom.destroy();

        // CONFIGURASI KHUSUS BIAR PINCH NYAMAN
        mapPanzoom = Panzoom(element, {
            maxScale: 6,
            minScale: 1,          // PERBAIKAN: Gak bisa lebih kecil dari ukuran layar
            startScale: 1,        // Mulai pas layar
            contain: null,        // Bebas geser (biar gak nyangkut)
            
            // PERBAIKAN FOCUS:
            // Kita matikan animasi saat drag/pinch biar responsif (nempel di jari)
            // Tapi nyalakan saat pakai tombol atau reset
            animate: false,       
            
            touchAction: 'none',
            cursor: 'default'
        });

        // Aktifkan Mouse Wheel dengan animasi
        element.parentElement.addEventListener('wheel', (e) => {
            mapPanzoom.zoomWithWheel(e, { animate: true });
        });

        // Sambungkan Tombol (Pakai animasi biar smooth kalau diklik)
        document.getElementById('zoomInBtn').onclick = () => mapPanzoom.zoomIn({ animate: true });
        document.getElementById('zoomOutBtn').onclick = () => mapPanzoom.zoomOut({ animate: true });
        document.getElementById('resetBtn').onclick = () => mapPanzoom.reset({ animate: true });

        // Force reset posisi biar pas tengah
        setTimeout(() => mapPanzoom.reset({ animate: false }), 50);
    });

    /* --- 3. TUTUP MODAL --- */
    document.getElementById('mapModal').addEventListener('hidden.bs.modal', function () {
        if (mapPanzoom) {
            mapPanzoom.reset({ animate: false });
        }
    });

    /* --- 4. GANTI LANTAI MODAL --- */
    function changeFloorModal(floor, el) {
        const img = document.getElementById('floorMapModal');
        const path = floor === 2 ? '{{ asset("img/lantai2.png") }}' : '{{ asset("img/lantai1.png") }}';
        
        img.style.opacity = '0.5';
        setTimeout(() => {
            img.src = path;
            img.onload = () => {
                img.style.opacity = '1';
                if(mapPanzoom) mapPanzoom.reset({ animate: false });
            };
        }, 150);
        updateModalButtons(floor);
    }

    function updateModalButtons(floor) {
        document.querySelectorAll('.btn-floor-modal').forEach(btn => btn.classList.remove('active'));
        const btns = document.querySelectorAll('.btn-floor-modal');
        if(btns[floor-1]) btns[floor-1].classList.add('active');
    }

    /* --- 5. FUNGSI UTAMA --- */
    function changeFloor(floor, el) {
        const img = document.getElementById('floorMap');
        const path = floor === 2 ? '{{ asset("img/lantai2.png") }}' : '{{ asset("img/lantai1.png") }}';
        img.src = path;
        document.querySelectorAll('.btn-floor').forEach(btn => btn.classList.remove('active'));
        if (el) el.classList.add('active');
    }

    function checkScreenSize() {
        const expandBtn = document.querySelector('[onclick="openMapFullscreen()"]');
        if (expandBtn) {
            expandBtn.style.display = window.innerWidth >= 1024 ? 'none' : 'flex';
        }
    }
    window.addEventListener('load', checkScreenSize);
    window.addEventListener('resize', checkScreenSize);
</script>

<style>
    /* GAMBAR MODAL */
    #floorMapModal {
        display: block;
        max-width: 100vw;   /* Batas lebar layar */
        max-height: 100vh;  /* Batas tinggi layar */
        width: auto;
        height: auto;
        object-fit: contain; 
        transition: opacity 0.2s ease; /* Hanya opacity, JANGAN transisi transform */
    }

    /* CANVAS HITAM */
    #panzoom-canvas {
        background-color: #000; 
        cursor: grab;
    }
    #panzoom-canvas:active {
        cursor: grabbing;
    }

    /* TOMBOL LANTAI */
    .btn-floor-modal {
        padding: 8px 24px;
        font-weight: 500;
        opacity: 0.7;
        transition: all 0.3s;
    }
    .btn-floor-modal:hover { opacity: 1; background: rgba(255,255,255,0.1); }
    .btn-floor-modal.active { opacity: 1; font-weight: bold; background: var(--oranye, #ff6b00); }

    /* LAYOUT */
    .map-container { position: relative; }
    .map-container .floor-controls { position: absolute; top: 0.75rem; left: 0.75rem; z-index: 1; }
    
    @media (max-width: 1023px) {
        .map-container { display: flex; flex-direction: column; }
        .map-container .floor-controls { position: static; order: 2; display: flex; justify-content: center; margin-top: 0.5rem; }
        .map-container img { order: 1; }
    }
    @media (min-width: 1024px) {
        [onclick="openMapFullscreen()"] { display: none !important; }
    }
</style>
@endsection